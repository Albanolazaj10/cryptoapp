export { default as Navbar } from './Navbar'; 
export { default as Cryptocurrencies } from './Cryptocurrencies'; 
export { default as Homepage } from './Homepage'; 
export { default as News } from './News'; 
